// generated from rosidl_generator_c/resource/idl.h.em
// with input from sobel_filter:srv/SobelFilter.idl
// generated code does not contain a copyright notice

#ifndef SOBEL_FILTER__SRV__SOBEL_FILTER_H_
#define SOBEL_FILTER__SRV__SOBEL_FILTER_H_

#include "sobel_filter/srv/detail/sobel_filter__struct.h"
#include "sobel_filter/srv/detail/sobel_filter__functions.h"
#include "sobel_filter/srv/detail/sobel_filter__type_support.h"

#endif  // SOBEL_FILTER__SRV__SOBEL_FILTER_H_
