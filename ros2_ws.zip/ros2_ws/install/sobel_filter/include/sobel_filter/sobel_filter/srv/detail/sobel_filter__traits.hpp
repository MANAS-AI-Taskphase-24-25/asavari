// generated from rosidl_generator_cpp/resource/idl__traits.hpp.em
// with input from sobel_filter:srv/SobelFilter.idl
// generated code does not contain a copyright notice

#ifndef SOBEL_FILTER__SRV__DETAIL__SOBEL_FILTER__TRAITS_HPP_
#define SOBEL_FILTER__SRV__DETAIL__SOBEL_FILTER__TRAITS_HPP_

#include <stdint.h>

#include <sstream>
#include <string>
#include <type_traits>

#include "sobel_filter/srv/detail/sobel_filter__struct.hpp"
#include "rosidl_runtime_cpp/traits.hpp"

namespace sobel_filter
{

namespace srv
{

inline void to_flow_style_yaml(
  const SobelFilter_Request & msg,
  std::ostream & out)
{
  out << "{";
  // member: width
  {
    out << "width: ";
    rosidl_generator_traits::value_to_yaml(msg.width, out);
    out << ", ";
  }

  // member: height
  {
    out << "height: ";
    rosidl_generator_traits::value_to_yaml(msg.height, out);
    out << ", ";
  }

  // member: data
  {
    if (msg.data.size() == 0) {
      out << "data: []";
    } else {
      out << "data: [";
      size_t pending_items = msg.data.size();
      for (auto item : msg.data) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const SobelFilter_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: width
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "width: ";
    rosidl_generator_traits::value_to_yaml(msg.width, out);
    out << "\n";
  }

  // member: height
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "height: ";
    rosidl_generator_traits::value_to_yaml(msg.height, out);
    out << "\n";
  }

  // member: data
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.data.size() == 0) {
      out << "data: []\n";
    } else {
      out << "data:\n";
      for (auto item : msg.data) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const SobelFilter_Request & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace srv

}  // namespace sobel_filter

namespace rosidl_generator_traits
{

[[deprecated("use sobel_filter::srv::to_block_style_yaml() instead")]]
inline void to_yaml(
  const sobel_filter::srv::SobelFilter_Request & msg,
  std::ostream & out, size_t indentation = 0)
{
  sobel_filter::srv::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use sobel_filter::srv::to_yaml() instead")]]
inline std::string to_yaml(const sobel_filter::srv::SobelFilter_Request & msg)
{
  return sobel_filter::srv::to_yaml(msg);
}

template<>
inline const char * data_type<sobel_filter::srv::SobelFilter_Request>()
{
  return "sobel_filter::srv::SobelFilter_Request";
}

template<>
inline const char * name<sobel_filter::srv::SobelFilter_Request>()
{
  return "sobel_filter/srv/SobelFilter_Request";
}

template<>
struct has_fixed_size<sobel_filter::srv::SobelFilter_Request>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<sobel_filter::srv::SobelFilter_Request>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<sobel_filter::srv::SobelFilter_Request>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace sobel_filter
{

namespace srv
{

inline void to_flow_style_yaml(
  const SobelFilter_Response & msg,
  std::ostream & out)
{
  out << "{";
  // member: width
  {
    out << "width: ";
    rosidl_generator_traits::value_to_yaml(msg.width, out);
    out << ", ";
  }

  // member: height
  {
    out << "height: ";
    rosidl_generator_traits::value_to_yaml(msg.height, out);
    out << ", ";
  }

  // member: processed_data
  {
    if (msg.processed_data.size() == 0) {
      out << "processed_data: []";
    } else {
      out << "processed_data: [";
      size_t pending_items = msg.processed_data.size();
      for (auto item : msg.processed_data) {
        rosidl_generator_traits::value_to_yaml(item, out);
        if (--pending_items > 0) {
          out << ", ";
        }
      }
      out << "]";
    }
  }
  out << "}";
}  // NOLINT(readability/fn_size)

inline void to_block_style_yaml(
  const SobelFilter_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  // member: width
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "width: ";
    rosidl_generator_traits::value_to_yaml(msg.width, out);
    out << "\n";
  }

  // member: height
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    out << "height: ";
    rosidl_generator_traits::value_to_yaml(msg.height, out);
    out << "\n";
  }

  // member: processed_data
  {
    if (indentation > 0) {
      out << std::string(indentation, ' ');
    }
    if (msg.processed_data.size() == 0) {
      out << "processed_data: []\n";
    } else {
      out << "processed_data:\n";
      for (auto item : msg.processed_data) {
        if (indentation > 0) {
          out << std::string(indentation, ' ');
        }
        out << "- ";
        rosidl_generator_traits::value_to_yaml(item, out);
        out << "\n";
      }
    }
  }
}  // NOLINT(readability/fn_size)

inline std::string to_yaml(const SobelFilter_Response & msg, bool use_flow_style = false)
{
  std::ostringstream out;
  if (use_flow_style) {
    to_flow_style_yaml(msg, out);
  } else {
    to_block_style_yaml(msg, out);
  }
  return out.str();
}

}  // namespace srv

}  // namespace sobel_filter

namespace rosidl_generator_traits
{

[[deprecated("use sobel_filter::srv::to_block_style_yaml() instead")]]
inline void to_yaml(
  const sobel_filter::srv::SobelFilter_Response & msg,
  std::ostream & out, size_t indentation = 0)
{
  sobel_filter::srv::to_block_style_yaml(msg, out, indentation);
}

[[deprecated("use sobel_filter::srv::to_yaml() instead")]]
inline std::string to_yaml(const sobel_filter::srv::SobelFilter_Response & msg)
{
  return sobel_filter::srv::to_yaml(msg);
}

template<>
inline const char * data_type<sobel_filter::srv::SobelFilter_Response>()
{
  return "sobel_filter::srv::SobelFilter_Response";
}

template<>
inline const char * name<sobel_filter::srv::SobelFilter_Response>()
{
  return "sobel_filter/srv/SobelFilter_Response";
}

template<>
struct has_fixed_size<sobel_filter::srv::SobelFilter_Response>
  : std::integral_constant<bool, false> {};

template<>
struct has_bounded_size<sobel_filter::srv::SobelFilter_Response>
  : std::integral_constant<bool, false> {};

template<>
struct is_message<sobel_filter::srv::SobelFilter_Response>
  : std::true_type {};

}  // namespace rosidl_generator_traits

namespace rosidl_generator_traits
{

template<>
inline const char * data_type<sobel_filter::srv::SobelFilter>()
{
  return "sobel_filter::srv::SobelFilter";
}

template<>
inline const char * name<sobel_filter::srv::SobelFilter>()
{
  return "sobel_filter/srv/SobelFilter";
}

template<>
struct has_fixed_size<sobel_filter::srv::SobelFilter>
  : std::integral_constant<
    bool,
    has_fixed_size<sobel_filter::srv::SobelFilter_Request>::value &&
    has_fixed_size<sobel_filter::srv::SobelFilter_Response>::value
  >
{
};

template<>
struct has_bounded_size<sobel_filter::srv::SobelFilter>
  : std::integral_constant<
    bool,
    has_bounded_size<sobel_filter::srv::SobelFilter_Request>::value &&
    has_bounded_size<sobel_filter::srv::SobelFilter_Response>::value
  >
{
};

template<>
struct is_service<sobel_filter::srv::SobelFilter>
  : std::true_type
{
};

template<>
struct is_service_request<sobel_filter::srv::SobelFilter_Request>
  : std::true_type
{
};

template<>
struct is_service_response<sobel_filter::srv::SobelFilter_Response>
  : std::true_type
{
};

}  // namespace rosidl_generator_traits

#endif  // SOBEL_FILTER__SRV__DETAIL__SOBEL_FILTER__TRAITS_HPP_
