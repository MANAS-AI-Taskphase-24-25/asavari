// generated from rosidl_generator_cpp/resource/idl__type_support.hpp.em
// with input from sobel_filter:srv/SobelFilter.idl
// generated code does not contain a copyright notice

#ifndef SOBEL_FILTER__SRV__DETAIL__SOBEL_FILTER__TYPE_SUPPORT_HPP_
#define SOBEL_FILTER__SRV__DETAIL__SOBEL_FILTER__TYPE_SUPPORT_HPP_

#include "rosidl_typesupport_interface/macros.h"

#include "sobel_filter/msg/rosidl_generator_cpp__visibility_control.hpp"

#include "rosidl_typesupport_cpp/service_type_support.hpp"

#ifdef __cplusplus
extern "C"
{
#endif
// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_CPP_PUBLIC_sobel_filter
const rosidl_service_type_support_t *
  ROSIDL_TYPESUPPORT_INTERFACE__SERVICE_SYMBOL_NAME(
  rosidl_typesupport_cpp,
  sobel_filter,
  srv,
  SobelFilter
)();
#ifdef __cplusplus
}
#endif

#include "rosidl_typesupport_cpp/message_type_support.hpp"

#ifdef __cplusplus
extern "C"
{
#endif
// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_CPP_PUBLIC_sobel_filter
const rosidl_message_type_support_t *
  ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_cpp,
  sobel_filter,
  srv,
  SobelFilter_Request
)();
#ifdef __cplusplus
}
#endif

// already included above
// #include "rosidl_typesupport_cpp/message_type_support.hpp"

#ifdef __cplusplus
extern "C"
{
#endif
// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_CPP_PUBLIC_sobel_filter
const rosidl_message_type_support_t *
  ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_cpp,
  sobel_filter,
  srv,
  SobelFilter_Response
)();
#ifdef __cplusplus
}
#endif


#endif  // SOBEL_FILTER__SRV__DETAIL__SOBEL_FILTER__TYPE_SUPPORT_HPP_
