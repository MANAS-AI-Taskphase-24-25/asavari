// generated from rosidl_generator_c/resource/idl__functions.h.em
// with input from sobel_filter:srv/SobelFilter.idl
// generated code does not contain a copyright notice

#ifndef SOBEL_FILTER__SRV__DETAIL__SOBEL_FILTER__FUNCTIONS_H_
#define SOBEL_FILTER__SRV__DETAIL__SOBEL_FILTER__FUNCTIONS_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stdlib.h>

#include "rosidl_runtime_c/visibility_control.h"
#include "sobel_filter/msg/rosidl_generator_c__visibility_control.h"

#include "sobel_filter/srv/detail/sobel_filter__struct.h"

/// Initialize srv/SobelFilter message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * sobel_filter__srv__SobelFilter_Request
 * )) before or use
 * sobel_filter__srv__SobelFilter_Request__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_sobel_filter
bool
sobel_filter__srv__SobelFilter_Request__init(sobel_filter__srv__SobelFilter_Request * msg);

/// Finalize srv/SobelFilter message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_sobel_filter
void
sobel_filter__srv__SobelFilter_Request__fini(sobel_filter__srv__SobelFilter_Request * msg);

/// Create srv/SobelFilter message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * sobel_filter__srv__SobelFilter_Request__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_sobel_filter
sobel_filter__srv__SobelFilter_Request *
sobel_filter__srv__SobelFilter_Request__create();

/// Destroy srv/SobelFilter message.
/**
 * It calls
 * sobel_filter__srv__SobelFilter_Request__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_sobel_filter
void
sobel_filter__srv__SobelFilter_Request__destroy(sobel_filter__srv__SobelFilter_Request * msg);

/// Check for srv/SobelFilter message equality.
/**
 * \param[in] lhs The message on the left hand size of the equality operator.
 * \param[in] rhs The message on the right hand size of the equality operator.
 * \return true if messages are equal, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_sobel_filter
bool
sobel_filter__srv__SobelFilter_Request__are_equal(const sobel_filter__srv__SobelFilter_Request * lhs, const sobel_filter__srv__SobelFilter_Request * rhs);

/// Copy a srv/SobelFilter message.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source message pointer.
 * \param[out] output The target message pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer is null
 *   or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_sobel_filter
bool
sobel_filter__srv__SobelFilter_Request__copy(
  const sobel_filter__srv__SobelFilter_Request * input,
  sobel_filter__srv__SobelFilter_Request * output);

/// Initialize array of srv/SobelFilter messages.
/**
 * It allocates the memory for the number of elements and calls
 * sobel_filter__srv__SobelFilter_Request__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_sobel_filter
bool
sobel_filter__srv__SobelFilter_Request__Sequence__init(sobel_filter__srv__SobelFilter_Request__Sequence * array, size_t size);

/// Finalize array of srv/SobelFilter messages.
/**
 * It calls
 * sobel_filter__srv__SobelFilter_Request__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_sobel_filter
void
sobel_filter__srv__SobelFilter_Request__Sequence__fini(sobel_filter__srv__SobelFilter_Request__Sequence * array);

/// Create array of srv/SobelFilter messages.
/**
 * It allocates the memory for the array and calls
 * sobel_filter__srv__SobelFilter_Request__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_sobel_filter
sobel_filter__srv__SobelFilter_Request__Sequence *
sobel_filter__srv__SobelFilter_Request__Sequence__create(size_t size);

/// Destroy array of srv/SobelFilter messages.
/**
 * It calls
 * sobel_filter__srv__SobelFilter_Request__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_sobel_filter
void
sobel_filter__srv__SobelFilter_Request__Sequence__destroy(sobel_filter__srv__SobelFilter_Request__Sequence * array);

/// Check for srv/SobelFilter message array equality.
/**
 * \param[in] lhs The message array on the left hand size of the equality operator.
 * \param[in] rhs The message array on the right hand size of the equality operator.
 * \return true if message arrays are equal in size and content, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_sobel_filter
bool
sobel_filter__srv__SobelFilter_Request__Sequence__are_equal(const sobel_filter__srv__SobelFilter_Request__Sequence * lhs, const sobel_filter__srv__SobelFilter_Request__Sequence * rhs);

/// Copy an array of srv/SobelFilter messages.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source array pointer.
 * \param[out] output The target array pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer
 *   is null or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_sobel_filter
bool
sobel_filter__srv__SobelFilter_Request__Sequence__copy(
  const sobel_filter__srv__SobelFilter_Request__Sequence * input,
  sobel_filter__srv__SobelFilter_Request__Sequence * output);

/// Initialize srv/SobelFilter message.
/**
 * If the init function is called twice for the same message without
 * calling fini inbetween previously allocated memory will be leaked.
 * \param[in,out] msg The previously allocated message pointer.
 * Fields without a default value will not be initialized by this function.
 * You might want to call memset(msg, 0, sizeof(
 * sobel_filter__srv__SobelFilter_Response
 * )) before or use
 * sobel_filter__srv__SobelFilter_Response__create()
 * to allocate and initialize the message.
 * \return true if initialization was successful, otherwise false
 */
ROSIDL_GENERATOR_C_PUBLIC_sobel_filter
bool
sobel_filter__srv__SobelFilter_Response__init(sobel_filter__srv__SobelFilter_Response * msg);

/// Finalize srv/SobelFilter message.
/**
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_sobel_filter
void
sobel_filter__srv__SobelFilter_Response__fini(sobel_filter__srv__SobelFilter_Response * msg);

/// Create srv/SobelFilter message.
/**
 * It allocates the memory for the message, sets the memory to zero, and
 * calls
 * sobel_filter__srv__SobelFilter_Response__init().
 * \return The pointer to the initialized message if successful,
 * otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_sobel_filter
sobel_filter__srv__SobelFilter_Response *
sobel_filter__srv__SobelFilter_Response__create();

/// Destroy srv/SobelFilter message.
/**
 * It calls
 * sobel_filter__srv__SobelFilter_Response__fini()
 * and frees the memory of the message.
 * \param[in,out] msg The allocated message pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_sobel_filter
void
sobel_filter__srv__SobelFilter_Response__destroy(sobel_filter__srv__SobelFilter_Response * msg);

/// Check for srv/SobelFilter message equality.
/**
 * \param[in] lhs The message on the left hand size of the equality operator.
 * \param[in] rhs The message on the right hand size of the equality operator.
 * \return true if messages are equal, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_sobel_filter
bool
sobel_filter__srv__SobelFilter_Response__are_equal(const sobel_filter__srv__SobelFilter_Response * lhs, const sobel_filter__srv__SobelFilter_Response * rhs);

/// Copy a srv/SobelFilter message.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source message pointer.
 * \param[out] output The target message pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer is null
 *   or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_sobel_filter
bool
sobel_filter__srv__SobelFilter_Response__copy(
  const sobel_filter__srv__SobelFilter_Response * input,
  sobel_filter__srv__SobelFilter_Response * output);

/// Initialize array of srv/SobelFilter messages.
/**
 * It allocates the memory for the number of elements and calls
 * sobel_filter__srv__SobelFilter_Response__init()
 * for each element of the array.
 * \param[in,out] array The allocated array pointer.
 * \param[in] size The size / capacity of the array.
 * \return true if initialization was successful, otherwise false
 * If the array pointer is valid and the size is zero it is guaranteed
 # to return true.
 */
ROSIDL_GENERATOR_C_PUBLIC_sobel_filter
bool
sobel_filter__srv__SobelFilter_Response__Sequence__init(sobel_filter__srv__SobelFilter_Response__Sequence * array, size_t size);

/// Finalize array of srv/SobelFilter messages.
/**
 * It calls
 * sobel_filter__srv__SobelFilter_Response__fini()
 * for each element of the array and frees the memory for the number of
 * elements.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_sobel_filter
void
sobel_filter__srv__SobelFilter_Response__Sequence__fini(sobel_filter__srv__SobelFilter_Response__Sequence * array);

/// Create array of srv/SobelFilter messages.
/**
 * It allocates the memory for the array and calls
 * sobel_filter__srv__SobelFilter_Response__Sequence__init().
 * \param[in] size The size / capacity of the array.
 * \return The pointer to the initialized array if successful, otherwise NULL
 */
ROSIDL_GENERATOR_C_PUBLIC_sobel_filter
sobel_filter__srv__SobelFilter_Response__Sequence *
sobel_filter__srv__SobelFilter_Response__Sequence__create(size_t size);

/// Destroy array of srv/SobelFilter messages.
/**
 * It calls
 * sobel_filter__srv__SobelFilter_Response__Sequence__fini()
 * on the array,
 * and frees the memory of the array.
 * \param[in,out] array The initialized array pointer.
 */
ROSIDL_GENERATOR_C_PUBLIC_sobel_filter
void
sobel_filter__srv__SobelFilter_Response__Sequence__destroy(sobel_filter__srv__SobelFilter_Response__Sequence * array);

/// Check for srv/SobelFilter message array equality.
/**
 * \param[in] lhs The message array on the left hand size of the equality operator.
 * \param[in] rhs The message array on the right hand size of the equality operator.
 * \return true if message arrays are equal in size and content, otherwise false.
 */
ROSIDL_GENERATOR_C_PUBLIC_sobel_filter
bool
sobel_filter__srv__SobelFilter_Response__Sequence__are_equal(const sobel_filter__srv__SobelFilter_Response__Sequence * lhs, const sobel_filter__srv__SobelFilter_Response__Sequence * rhs);

/// Copy an array of srv/SobelFilter messages.
/**
 * This functions performs a deep copy, as opposed to the shallow copy that
 * plain assignment yields.
 *
 * \param[in] input The source array pointer.
 * \param[out] output The target array pointer, which must
 *   have been initialized before calling this function.
 * \return true if successful, or false if either pointer
 *   is null or memory allocation fails.
 */
ROSIDL_GENERATOR_C_PUBLIC_sobel_filter
bool
sobel_filter__srv__SobelFilter_Response__Sequence__copy(
  const sobel_filter__srv__SobelFilter_Response__Sequence * input,
  sobel_filter__srv__SobelFilter_Response__Sequence * output);

#ifdef __cplusplus
}
#endif

#endif  // SOBEL_FILTER__SRV__DETAIL__SOBEL_FILTER__FUNCTIONS_H_
