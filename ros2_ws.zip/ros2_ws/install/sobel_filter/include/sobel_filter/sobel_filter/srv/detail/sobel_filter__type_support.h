// generated from rosidl_generator_c/resource/idl__type_support.h.em
// with input from sobel_filter:srv/SobelFilter.idl
// generated code does not contain a copyright notice

#ifndef SOBEL_FILTER__SRV__DETAIL__SOBEL_FILTER__TYPE_SUPPORT_H_
#define SOBEL_FILTER__SRV__DETAIL__SOBEL_FILTER__TYPE_SUPPORT_H_

#include "rosidl_typesupport_interface/macros.h"

#include "sobel_filter/msg/rosidl_generator_c__visibility_control.h"

#ifdef __cplusplus
extern "C"
{
#endif

#include "rosidl_runtime_c/message_type_support_struct.h"

// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_C_PUBLIC_sobel_filter
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_c,
  sobel_filter,
  srv,
  SobelFilter_Request
)();

// already included above
// #include "rosidl_runtime_c/message_type_support_struct.h"

// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_C_PUBLIC_sobel_filter
const rosidl_message_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__MESSAGE_SYMBOL_NAME(
  rosidl_typesupport_c,
  sobel_filter,
  srv,
  SobelFilter_Response
)();

#include "rosidl_runtime_c/service_type_support_struct.h"

// Forward declare the get type support functions for this type.
ROSIDL_GENERATOR_C_PUBLIC_sobel_filter
const rosidl_service_type_support_t *
ROSIDL_TYPESUPPORT_INTERFACE__SERVICE_SYMBOL_NAME(
  rosidl_typesupport_c,
  sobel_filter,
  srv,
  SobelFilter
)();

#ifdef __cplusplus
}
#endif

#endif  // SOBEL_FILTER__SRV__DETAIL__SOBEL_FILTER__TYPE_SUPPORT_H_
