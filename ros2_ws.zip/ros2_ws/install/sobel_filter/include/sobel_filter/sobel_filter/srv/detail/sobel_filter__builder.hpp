// generated from rosidl_generator_cpp/resource/idl__builder.hpp.em
// with input from sobel_filter:srv/SobelFilter.idl
// generated code does not contain a copyright notice

#ifndef SOBEL_FILTER__SRV__DETAIL__SOBEL_FILTER__BUILDER_HPP_
#define SOBEL_FILTER__SRV__DETAIL__SOBEL_FILTER__BUILDER_HPP_

#include <algorithm>
#include <utility>

#include "sobel_filter/srv/detail/sobel_filter__struct.hpp"
#include "rosidl_runtime_cpp/message_initialization.hpp"


namespace sobel_filter
{

namespace srv
{

namespace builder
{

class Init_SobelFilter_Request_data
{
public:
  explicit Init_SobelFilter_Request_data(::sobel_filter::srv::SobelFilter_Request & msg)
  : msg_(msg)
  {}
  ::sobel_filter::srv::SobelFilter_Request data(::sobel_filter::srv::SobelFilter_Request::_data_type arg)
  {
    msg_.data = std::move(arg);
    return std::move(msg_);
  }

private:
  ::sobel_filter::srv::SobelFilter_Request msg_;
};

class Init_SobelFilter_Request_height
{
public:
  explicit Init_SobelFilter_Request_height(::sobel_filter::srv::SobelFilter_Request & msg)
  : msg_(msg)
  {}
  Init_SobelFilter_Request_data height(::sobel_filter::srv::SobelFilter_Request::_height_type arg)
  {
    msg_.height = std::move(arg);
    return Init_SobelFilter_Request_data(msg_);
  }

private:
  ::sobel_filter::srv::SobelFilter_Request msg_;
};

class Init_SobelFilter_Request_width
{
public:
  Init_SobelFilter_Request_width()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_SobelFilter_Request_height width(::sobel_filter::srv::SobelFilter_Request::_width_type arg)
  {
    msg_.width = std::move(arg);
    return Init_SobelFilter_Request_height(msg_);
  }

private:
  ::sobel_filter::srv::SobelFilter_Request msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::sobel_filter::srv::SobelFilter_Request>()
{
  return sobel_filter::srv::builder::Init_SobelFilter_Request_width();
}

}  // namespace sobel_filter


namespace sobel_filter
{

namespace srv
{

namespace builder
{

class Init_SobelFilter_Response_processed_data
{
public:
  explicit Init_SobelFilter_Response_processed_data(::sobel_filter::srv::SobelFilter_Response & msg)
  : msg_(msg)
  {}
  ::sobel_filter::srv::SobelFilter_Response processed_data(::sobel_filter::srv::SobelFilter_Response::_processed_data_type arg)
  {
    msg_.processed_data = std::move(arg);
    return std::move(msg_);
  }

private:
  ::sobel_filter::srv::SobelFilter_Response msg_;
};

class Init_SobelFilter_Response_height
{
public:
  explicit Init_SobelFilter_Response_height(::sobel_filter::srv::SobelFilter_Response & msg)
  : msg_(msg)
  {}
  Init_SobelFilter_Response_processed_data height(::sobel_filter::srv::SobelFilter_Response::_height_type arg)
  {
    msg_.height = std::move(arg);
    return Init_SobelFilter_Response_processed_data(msg_);
  }

private:
  ::sobel_filter::srv::SobelFilter_Response msg_;
};

class Init_SobelFilter_Response_width
{
public:
  Init_SobelFilter_Response_width()
  : msg_(::rosidl_runtime_cpp::MessageInitialization::SKIP)
  {}
  Init_SobelFilter_Response_height width(::sobel_filter::srv::SobelFilter_Response::_width_type arg)
  {
    msg_.width = std::move(arg);
    return Init_SobelFilter_Response_height(msg_);
  }

private:
  ::sobel_filter::srv::SobelFilter_Response msg_;
};

}  // namespace builder

}  // namespace srv

template<typename MessageType>
auto build();

template<>
inline
auto build<::sobel_filter::srv::SobelFilter_Response>()
{
  return sobel_filter::srv::builder::Init_SobelFilter_Response_width();
}

}  // namespace sobel_filter

#endif  // SOBEL_FILTER__SRV__DETAIL__SOBEL_FILTER__BUILDER_HPP_
