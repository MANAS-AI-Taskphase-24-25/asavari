// generated from rosidl_generator_c/resource/idl__struct.h.em
// with input from sobel_filter:srv/SobelFilter.idl
// generated code does not contain a copyright notice

#ifndef SOBEL_FILTER__SRV__DETAIL__SOBEL_FILTER__STRUCT_H_
#define SOBEL_FILTER__SRV__DETAIL__SOBEL_FILTER__STRUCT_H_

#ifdef __cplusplus
extern "C"
{
#endif

#include <stdbool.h>
#include <stddef.h>
#include <stdint.h>


// Constants defined in the message

// Include directives for member types
// Member 'data'
#include "rosidl_runtime_c/primitives_sequence.h"

/// Struct defined in srv/SobelFilter in the package sobel_filter.
typedef struct sobel_filter__srv__SobelFilter_Request
{
  int32_t width;
  int32_t height;
  rosidl_runtime_c__int32__Sequence data;
} sobel_filter__srv__SobelFilter_Request;

// Struct for a sequence of sobel_filter__srv__SobelFilter_Request.
typedef struct sobel_filter__srv__SobelFilter_Request__Sequence
{
  sobel_filter__srv__SobelFilter_Request * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} sobel_filter__srv__SobelFilter_Request__Sequence;


// Constants defined in the message

// Include directives for member types
// Member 'processed_data'
// already included above
// #include "rosidl_runtime_c/primitives_sequence.h"

/// Struct defined in srv/SobelFilter in the package sobel_filter.
typedef struct sobel_filter__srv__SobelFilter_Response
{
  int32_t width;
  int32_t height;
  rosidl_runtime_c__int32__Sequence processed_data;
} sobel_filter__srv__SobelFilter_Response;

// Struct for a sequence of sobel_filter__srv__SobelFilter_Response.
typedef struct sobel_filter__srv__SobelFilter_Response__Sequence
{
  sobel_filter__srv__SobelFilter_Response * data;
  /// The number of valid items in data
  size_t size;
  /// The number of allocated items in data
  size_t capacity;
} sobel_filter__srv__SobelFilter_Response__Sequence;

#ifdef __cplusplus
}
#endif

#endif  // SOBEL_FILTER__SRV__DETAIL__SOBEL_FILTER__STRUCT_H_
