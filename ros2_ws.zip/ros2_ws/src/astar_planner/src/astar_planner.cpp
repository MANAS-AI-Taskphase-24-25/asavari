#include <vector>
#include <queue>
#include <memory>
#include <cmath>
#include <limits>
#include "rclcpp/rclcpp.hpp"
#include "nav_msgs/msg/path.hpp"
#include "geometry_msgs/msg/pose_stamped.hpp"

struct AStarNode {
    int x, y;
    double g, h;
    std::shared_ptr<AStarNode> parent;

    AStarNode(int x, int y, double g, double h, std::shared_ptr<AStarNode> parent = nullptr)
        : x(x), y(y), g(g), h(h), parent(parent) {}
};

class AStarPlanner : public rclcpp::Node {
public:
    AStarPlanner() : Node("astar_planner") {
        path_pub_ = this->create_publisher<nav_msgs::msg::Path>("astar_path", 10);
        
        // timer
        timer_ = this->create_wall_timer(
            std::chrono::seconds(1), 
            std::bind(&AStarPlanner::plan_and_publish, this)
        );
    }

private:
    rclcpp::Publisher<nav_msgs::msg::Path>::SharedPtr path_pub_;
    rclcpp::TimerBase::SharedPtr timer_;

    void plan_and_publish() {
        // start and goal
        int start_x = 0, start_y = 0;
        int goal_x = 5, goal_y = 5;

        std::vector<std::pair<int, int>> path = a_star(start_x, start_y, goal_x, goal_y);
        
        if (!path.empty()) {
            publish_path(path);
            RCLCPP_INFO(this->get_logger(), "Path published successfully.");
        } else {
            RCLCPP_WARN(this->get_logger(), "A* failed to find a path.");
        }
    }

    void publish_path(const std::vector<std::pair<int, int>>& path) {
        nav_msgs::msg::Path path_msg;
        path_msg.header.stamp = this->now();
        path_msg.header.frame_id = "map";

        for (const auto& point : path) {
            geometry_msgs::msg::PoseStamped pose;
            pose.header = path_msg.header;
            pose.pose.position.x = point.first;
            pose.pose.position.y = point.second;
            pose.pose.position.z = 0.0;
            path_msg.poses.push_back(pose);
        }

        path_pub_->publish(path_msg);
    }

    std::vector<std::pair<int, int>> a_star(int start_x, int start_y, int goal_x, int goal_y) {
        auto start = std::make_shared<AStarNode>(start_x, start_y, 0.0, heuristic(start_x, start_y, goal_x, goal_y));
        
        auto cmp = [](const std::shared_ptr<AStarNode>& a, const std::shared_ptr<AStarNode>& b) {
            return (a->g + a->h) > (b->g + b->h);
        };

        std::priority_queue<
            std::shared_ptr<AStarNode>, 
            std::vector<std::shared_ptr<AStarNode>>, 
            decltype(cmp)
        > open_list(cmp);

        open_list.push(start);
        std::vector<std::pair<int, int>> path;

        while (!open_list.empty()) {
            auto current = open_list.top();
            open_list.pop();

            if (current->x == goal_x && current->y == goal_y) {
                while (current) {
                    path.emplace_back(current->x, current->y);
                    current = current->parent;
                }
                std::reverse(path.begin(), path.end());
                return path;
            }

            for (const auto& [dx, dy] : std::vector<std::pair<int, int>>{{1,0}, {0,1}, {-1,0}, {0,-1}}) {
                int nx = current->x + dx;
                int ny = current->y + dy;
                double g_new = current->g + 1.0;
                double h_new = heuristic(nx, ny, goal_x, goal_y);
                open_list.push(std::make_shared<AStarNode>(nx, ny, g_new, h_new, current));
            }
        }

        return {}; 
    }

    double heuristic(int x1, int y1, int x2, int y2) {
        return std::sqrt(std::pow(x1 - x2, 2) + std::pow(y1 - y2, 2));
    }
};

int main(int argc, char **argv) {
    rclcpp::init(argc, argv);
    auto node = std::make_shared<AStarPlanner>();
    rclcpp::spin(node);
    rclcpp::shutdown();
    return 0;
}

