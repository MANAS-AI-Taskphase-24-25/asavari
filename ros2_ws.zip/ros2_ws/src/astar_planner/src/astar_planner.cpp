#include <rclcpp/rclcpp.hpp>
#include <nav_msgs/msg/occupancy_grid.hpp>
#include <nav_msgs/msg/path.hpp>
#include <geometry_msgs/msg/pose_stamped.hpp>
#include <queue>
#include <vector>
#include <cmath>
#include <unordered_map>

using namespace std;

struct Node {
    int x, y;
    float g, h, f;
    Node* parent;
};

class AStarPlanner : public rclcpp::Node {
public:
    AStarPlanner() : Node("astar_planner") {
        map_sub_ = this->create_subscription<nav_msgs::msg::OccupancyGrid>(
            "/map", 10, std::bind(&AStarPlanner::map_callback, this, std::placeholders::_1));
        
        path_pub_ = this->create_publisher<nav_msgs::msg::Path>("/planned_path", 10);
    }

private:
    rclcpp::Subscription<nav_msgs::msg::OccupancyGrid>::SharedPtr map_sub_;
    rclcpp::Publisher<nav_msgs::msg::Path>::SharedPtr path_pub_;
    nav_msgs::msg::OccupancyGrid map_;

    void map_callback(const nav_msgs::msg::OccupancyGrid::SharedPtr msg) {
        map_ = *msg;
        RCLCPP_INFO(this->get_logger(), "Received map. Starting A* path planning...");

        int start_x = 5, start_y = 5;  // Example start
        int goal_x = 50, goal_y = 50;  // Example goal

        vector<pair<int, int>> path = a_star(start_x, start_y, goal_x, goal_y);

        publish_path(path);
    }

    vector<pair<int, int>> a_star(int start_x, int start_y, int goal_x, int goal_y) {
        auto heuristic = [](int x1, int y1, int x2, int y2) {
            return hypot(x1 - x2, y1 - y2);  // Euclidean distance
        };

        priority_queue<pair<float, Node*>, vector<pair<float, Node*>>, greater<>> open_list;
        unordered_map<int, Node*> all_nodes;
        vector<pair<int, int>> path;

        Node* start = new Node{start_x, start_y, 0, heuristic(start_x, start_y, goal_x, goal_y), 0, nullptr};
        open_list.push({start->f, start});
        all_nodes[start_x + start_y * map_.info.width] = start;

        vector<pair<int, int>> directions = {{1, 0}, {-1, 0}, {0, 1}, {0, -1}};

        while (!open_list.empty()) {
            Node* current = open_list.top().second;
            open_list.pop();

            if (current->x == goal_x && current->y == goal_y) {
                while (current) {
                    path.push_back({current->x, current->y});
                    current = current->parent;
                }
                reverse(path.begin(), path.end());
                break;
            }

            for (auto [dx, dy] : directions) {
                int nx = current->x + dx, ny = current->y + dy;
                if (nx < 0 || ny < 0 || nx >= map_.info.width || ny >= map_.info.height) continue;

                int index = nx + ny * map_.info.width;
                if (map_.data[index] > 50) continue;  // Obstacle threshold

                float g_new = current->g + 1;
                float h_new = heuristic(nx, ny, goal_x, goal_y);
                float f_new = g_new + h_new;

                if (!all_nodes.count(index) || all_nodes[index]->f > f_new) {
                    Node* neighbor = new Node{nx, ny, g_new, h_new, f_new, current};
                    open_list.push({f_new, neighbor});
                    all_nodes[index] = neighbor;
                }
            }
        }

        return path;
    }

    void publish_path(const vector<pair<int, int>>& path) {
        nav_msgs::msg::Path ros_path;
        ros_path.header.stamp = this->now();
        ros_path.header.frame_id = "map";

        for (auto [x, y] : path) {
            geometry_msgs::msg::PoseStamped pose;
            pose.pose.position.x = x * map_.info.resolution + map_.info.origin.position.x;
            pose.pose.position.y = y * map_.info.resolution + map_.info.origin.position.y;
            ros_path.poses.push_back(pose);
        }

        path_pub_->publish(ros_path);
        RCLCPP_INFO(this->get_logger(), "Published planned path!");
    }
};

int main(int argc, char** argv) {
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<AStarPlanner>());
    rclcpp::shutdown();
    return 0;
}

