import rclpy
from rclpy.node import Node
from std_msgs.msg import String
import threading


class ChatNode(Node):
    def __init__(self, user_name, send_topic, receive_topic):
        super().__init__(user_name)
        
        # Publisher to send messages
        self.publisher_ = self.create_publisher(String, send_topic, 10)
        
        # Subscriber to receive messages
        self.subscription = self.create_subscription(
            String, 
            receive_topic, 
            self.listener_callback, 
            10
        )
        
        self.get_logger().info(f'{user_name} started. Listening on {receive_topic} and sending on {send_topic}.')

        # Run input handling in a separate thread
        thread = threading.Thread(target=self.send_message_loop)
        thread.daemon = True
        thread.start()

    def listener_callback(self, msg):
        """Callback function that executes when a message is received."""
        self.get_logger().info(f'Friend: "{msg.data}"')

    def send_message_loop(self):
        """Loop to take user input and publish messages."""
        while rclpy.ok():
            message = String()
            message.data = input("You: ")
            self.publisher_.publish(message)
            self.get_logger().info(f'You sent: "{message.data}"')


def main(args=None):
    rclpy.init(args=args)

    # Define user roles
    user_name = input("Enter your name (User1/User2): ").strip()
    
    if user_name.lower() == "user1":
        send_topic = "user1_topic"
        receive_topic = "user2_topic"
    elif user_name.lower() == "user2":
        send_topic = "user2_topic"
        receive_topic = "user1_topic"
    else:
        print("Invalid name! Please restart and enter 'User1' or 'User2'.")
        return

    node = ChatNode(user_name, send_topic, receive_topic)

    try:
        rclpy.spin(node)
    except KeyboardInterrupt:
        pass

    node.destroy_node()
    rclpy.shutdown()


if __name__ == '__main__':
    main()

