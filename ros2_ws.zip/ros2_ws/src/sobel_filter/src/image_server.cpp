#include "rclcpp/rclcpp.hpp"
#include "sobel_filter/srv/sobel_filter.hpp"
#include <vector>
#include <opencv4/opencv2/opencv.hpp>

using namespace std;
using namespace cv;
using std::placeholders::_1;
using std::placeholders::_2;

class SobelFilterServer : public rclcpp::Node {
public:
    SobelFilterServer() : Node("sobel_filter_server") {
        service_ = this->create_service<sobel_filter::srv::SobelFilter>(
            "apply_sobel_filter",
            std::bind(&SobelFilterServer::process_image, this, _1, _2)
        );
        RCLCPP_INFO(this->get_logger(), "Sobel Filter Server Ready.");
    }

private:
    void process_image(
        const std::shared_ptr<sobel_filter::srv::SobelFilter::Request> request,
        std::shared_ptr<sobel_filter::srv::SobelFilter::Response> response
    ) {
        int width = request->width;
        int height = request->height;
        std::vector<int32_t> input_data = request->data;

        // Convert flattened array to matrix
        Mat image(height, width, CV_32S, input_data.data());
        image.convertTo(image, CV_8U);  // Ensure correct format for OpenCV operations

        RCLCPP_INFO(this->get_logger(), "Received image: width=%d, height=%d, type=%d", width, height, image.type());

        // Apply Sobel filter
        Mat sobelX, sobelY, sobel;
        Sobel(image, sobelX, CV_16S, 1, 0, 3);
        Sobel(image, sobelY, CV_16S, 0, 1, 3);
        sobel = abs(sobelX) + abs(sobelY);
        
        // Convert back to 8-bit before sending
        sobel.convertTo(sobel, CV_8U);

        // Flatten the result
        std::vector<int32_t> processed_data(sobel.begin<uint8_t>(), sobel.end<uint8_t>());

        response->width = width;
        response->height = height;
        response->processed_data = processed_data;

        RCLCPP_INFO(this->get_logger(), "Processed image sent back.");
    }

    rclcpp::Service<sobel_filter::srv::SobelFilter>::SharedPtr service_;
};

int main(int argc, char **argv) {
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<SobelFilterServer>());
    rclcpp::shutdown();
    return 0;
}
