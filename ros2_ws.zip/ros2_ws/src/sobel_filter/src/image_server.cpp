#include "rclcpp/rclcpp.hpp"
#include "sobel_filter/srv/sobel_filter.hpp"
#include <vector>
#include <opencv2/opencv.hpp>

using namespace std;
using namespace cv;
using std::placeholders::_1;
using std::placeholders::_2;

class SobelFilterServer : public rclcpp::Node {
public:
    SobelFilterServer() : Node("sobel_filter_server") {
        service_ = this->create_service<sobel_filter::srv::SobelFilter>(
            "apply_sobel_filter",
            std::bind(&SobelFilterServer::process_image, this, _1, _2)
        );
        RCLCPP_INFO(this->get_logger(), "Sobel Filter Server Ready.");
    }

private:
    void process_image(
        const std::shared_ptr<sobel_filter::srv::SobelFilter::Request> request,
        std::shared_ptr<sobel_filter::srv::SobelFilter::Response> response
    ) {
        int width = request->width;
        int height = request->height;
        std::vector<int32_t> input_data = request->data;

        //flattened array to matrix
        Mat image(height, width, CV_32S, input_data.data());

        //Sobel filter
        Mat sobelX, sobelY, sobel;
        Sobel(image, sobelX, CV_32S, 1, 0);
        Sobel(image, sobelY, CV_32S, 0, 1);
        sobel = abs(sobelX) + abs(sobelY);

        //result
        sobel = sobel.reshape(1, height * width);
        std::vector<int32_t> processed_data(sobel.begin<int>(), sobel.end<int>());

        response->width = width;
        response->height = height;
        response->processed_data = processed_data;

        RCLCPP_INFO(this->get_logger(), "Processed image sent back.");
    }

    rclcpp::Service<sobel_filter::srv::SobelFilter>::SharedPtr service_;
};

int main(int argc, char **argv) {
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<SobelFilterServer>());
    rclcpp::shutdown();
    return 0;
}

