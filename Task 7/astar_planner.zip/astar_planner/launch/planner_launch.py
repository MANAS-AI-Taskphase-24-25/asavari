from launch import LaunchDescription
from launch_ros.actions import Node
from launch.actions import DeclareLaunchArgument
from launch.substitutions import LaunchConfiguration, PathJoinSubstitution
from ament_index_python.packages import get_package_share_directory

def generate_launch_description():
    pkg_dir = get_package_share_directory('astar_planner')

    return LaunchDescription([
        DeclareLaunchArgument('heuristic', default_value='manhattan'),
        Node(
            package='nav2_map_server',
            executable='map_server',
            name='map_server',
            output='screen',
            parameters=[{'yaml_filename': PathJoinSubstitution([pkg_dir, 'maps', 'map.yaml'])}]    
        ),
        Node(
            package='astar_planner',
            executable='astar_planner',
            name='astar_planner',
            output='screen',
            parameters=[{'heuristic': LaunchConfiguration('heuristic')}],
        ),
        
        Node(
    	    package='nav2_lifecycle_manager',
            executable='lifecycle_manager',
    	    name='lifecycle_manager',
    	    output='screen',
    	    parameters=[{'use_sim_time': False, 'autostart': True, 'node_names': ['map_server']}]
	)
    ])
