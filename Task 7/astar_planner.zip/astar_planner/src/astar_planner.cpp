#include "rclcpp/rclcpp.hpp"
#include "rclcpp/qos.hpp"
#include "nav_msgs/msg/occupancy_grid.hpp"
#include "nav_msgs/msg/path.hpp"
#include "geometry_msgs/msg/pose_stamped.hpp"
#include "geometry_msgs/msg/pose_with_covariance_stamped.hpp"
#include <vector>
#include <queue>
#include <cmath>
#include <unordered_map>

struct AStarNode
{
    int x, y;
    float g_cost, h_cost;
    AStarNode *parent;

    float total_cost() const { return g_cost + h_cost; }
    bool operator>(const AStarNode &other) const { return total_cost() > other.total_cost(); }
};

class Planner : public rclcpp::Node
{
public:
    Planner() : Node("planner"), heuristic_type_(declare_parameter("heuristic", "manhattan"))
    {
        map_sub_ = this->create_subscription<nav_msgs::msg::OccupancyGrid>(
            "/map", 10, std::bind(&Planner::mapCallback, this, std::placeholders::_1));

        rclcpp::QoS qos_settings = rclcpp::QoS(rclcpp::KeepLast(1)).transient_local().reliable();
        path_pub_ = this->create_publisher<nav_msgs::msg::Path>("/planned_path", qos_settings);
        
        start_sub_ = this->create_subscription<geometry_msgs::msg::PoseWithCovarianceStamped>(
            "/initialpose", 10, std::bind(&Planner::startCallback, this, std::placeholders::_1));
        
        goal_sub_ = this->create_subscription<geometry_msgs::msg::PoseStamped>(
            "/goal_pose", 10, std::bind(&Planner::goalCallback, this, std::placeholders::_1));
    }

private:
    int start_x_ = -1, start_y_ = -1, goal_x_ = -1, goal_y_ = -1;
    float map_resolution_;
    float origin_x_, origin_y_;
    
    rclcpp::Subscription<geometry_msgs::msg::PoseWithCovarianceStamped>::SharedPtr start_sub_;
    rclcpp::Subscription<geometry_msgs::msg::PoseStamped>::SharedPtr goal_sub_;
    rclcpp::Subscription<nav_msgs::msg::OccupancyGrid>::SharedPtr map_sub_;
    rclcpp::Publisher<nav_msgs::msg::Path>::SharedPtr path_pub_;
    
    nav_msgs::msg::OccupancyGrid::SharedPtr latest_map_;
    std::string heuristic_type_;

    
    void worldToGrid(float wx, float wy, int &gx, int &gy)
    {
        gx = static_cast<int>((wx - origin_x_) / map_resolution_);
        gy = static_cast<int>((wy - origin_y_) / map_resolution_);
    }

    void startCallback(const geometry_msgs::msg::PoseWithCovarianceStamped::SharedPtr msg)
    {
        worldToGrid(msg->pose.pose.position.x, msg->pose.pose.position.y, start_x_, start_y_);
        RCLCPP_INFO(this->get_logger(), "Start set: (%d, %d)", start_x_, start_y_);
        attemptReplan();
    }

    void goalCallback(const geometry_msgs::msg::PoseStamped::SharedPtr msg)
    {
        worldToGrid(msg->pose.position.x, msg->pose.position.y, goal_x_, goal_y_);
        RCLCPP_INFO(this->get_logger(), "Goal set: (%d, %d)", goal_x_, goal_y_);
        attemptReplan();
    }

    void mapCallback(const nav_msgs::msg::OccupancyGrid::SharedPtr msg)
    {
        latest_map_ = msg;
        map_resolution_ = msg->info.resolution;
        origin_x_ = msg->info.origin.position.x;
        origin_y_ = msg->info.origin.position.y;

        RCLCPP_INFO(this->get_logger(), "Map loaded: %d x %d, resolution: %.2f", msg->info.width, msg->info.height, map_resolution_);
        attemptReplan();
    }

    void attemptReplan()
    {
        if (!latest_map_)
        {
            RCLCPP_WARN(this->get_logger(), "Map not received yet.");
            return;
        }

        if (start_x_ >= 0 && start_y_ >= 0 && goal_x_ >= 0 && goal_y_ >= 0)
        {
            RCLCPP_INFO(this->get_logger(), "Planning path...");
            auto path = findPath(latest_map_, start_x_, start_y_, goal_x_, goal_y_);
            publishPath(path);
        }
    }

    float calculateHeuristic(int x1, int y1, int x2, int y2)
    {
        if (heuristic_type_ == "euclidean")
            return std::sqrt(std::pow(x2 - x1, 2) + std::pow(y2 - y1, 2));
        return std::abs(x2 - x1) + std::abs(y2 - y1);
    }
    
    // A* starts here

    std::vector<AStarNode> findPath(const nav_msgs::msg::OccupancyGrid::SharedPtr &map, int start_x, int start_y, int goal_x, int goal_y)
    {
        int width = map->info.width, height = map->info.height;
        std::priority_queue<AStarNode, std::vector<AStarNode>, std::greater<AStarNode>> open_set;
        std::vector<std::vector<bool>> visited(width, std::vector<bool>(height, false));

        open_set.push({start_x, start_y, 0, calculateHeuristic(start_x, start_y, goal_x, goal_y), nullptr});

        while (!open_set.empty())
        {
            AStarNode current = open_set.top();
            open_set.pop();

            if (current.x == goal_x && current.y == goal_y)
            {
                std::vector<AStarNode> path;
                while (current.parent)
                {
                    path.push_back(current);
                    current = *current.parent;
                }
                std::reverse(path.begin(), path.end());
                return path;
            }

            if (visited[current.x][current.y])
                continue;
            visited[current.x][current.y] = true;

            for (auto [dx, dy] : std::vector<std::pair<int, int>>{{1, 0}, {-1, 0}, {0, 1}, {0, -1}, {1, 1}, {1, -1}, {-1, 1}, {-1, -1}}) 
            {
                int nx = current.x + dx, ny = current.y + dy;
                if (nx >= 0 && ny >= 0 && nx < width && ny < height)
                {
                    int index = ny * width + nx;
                    if (map->data[index] < 50)
                    {
                        float extra_cost = (dx != 0 && dy != 0) ? 1.414 : 1.0;
                        open_set.push({nx, ny, current.g_cost + extra_cost, calculateHeuristic(nx, ny, goal_x, goal_y), new AStarNode(current)});
                    }
                }
            }
        }
        return {};
    }

    void publishPath(const std::vector<AStarNode> &path)
    {
        nav_msgs::msg::Path ros_path;
        ros_path.header.stamp = this->get_clock()->now();
        ros_path.header.frame_id = "map";

        for (const auto &node : path)
        {
            geometry_msgs::msg::PoseStamped pose;
            pose.pose.position.x = node.x * map_resolution_ + origin_x_;
            pose.pose.position.y = node.y * map_resolution_ + origin_y_;
            pose.pose.orientation.w = 1.0;
            ros_path.poses.push_back(pose);
        }

        RCLCPP_INFO(this->get_logger(), "Publishing path...");
        path_pub_->publish(ros_path);
    }
};

int main(int argc, char **argv)
{
    rclcpp::init(argc, argv);
    rclcpp::spin(std::make_shared<Planner>());
    rclcpp::shutdown();
    return 0;
}

