#include "rclcpp/rclcpp.hpp"
#include "sobel_filter/srv/sobel_filter.hpp"
#include <vector>

using namespace std;

int main(int argc, char **argv) {
    rclcpp::init(argc, argv);
    auto node = rclcpp::Node::make_shared("sobel_filter_client");
    auto client = node->create_client<sobel_filter::srv::SobelFilter>("apply_sobel_filter");

    auto request = std::make_shared<sobel_filter::srv::SobelFilter::Request>();
    request->width = 3;
    request->height = 3;
    request->data = {1, 2, 3, 4, 5, 6, 7, 8, 9};  // Example 3x3 image

    while (!client->wait_for_service(std::chrono::seconds(1))) {
        RCLCPP_INFO(node->get_logger(), "Waiting for Sobel Filter Server...");
    }

    auto result = client->async_send_request(request);
    if (rclcpp::spin_until_future_complete(node, result) == rclcpp::FutureReturnCode::SUCCESS) {
        auto response = result.get();
        RCLCPP_INFO(node->get_logger(), "Received processed image:");
        
        for (int i = 0; i < response->height; ++i) {
            for (int j = 0; j < response->width; ++j) {
                cout << response->processed_data[i * response->width + j] << " ";
            }
            cout << endl;
        }
    } else {
        RCLCPP_ERROR(node->get_logger(), "Service call failed.");
    }

    rclcpp::shutdown();
    return 0;
}

